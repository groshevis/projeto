import {Component} from '@angular/core';

@Component({
  selector:'progresso.component',
  templateUrl:'progresso.component.html'
})

export class ProgressoComponent{

  
}
