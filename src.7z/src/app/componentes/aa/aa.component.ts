import {Component} from '@angular/core';

@Component({
  selector:'aa.component',
  templateUrl:'aa.component.html'
})

export class AaComponent{
  horas:String;
  anotacoes:String;
  dominio:String;
}
